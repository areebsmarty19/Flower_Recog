package com.example.flower;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class ProfileActivity extends AppCompatActivity {

    private TextView textViewName;
    private ImageView imageViewProfile;
    private Button saveButton;

    private String imagePath;

    private ImageDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        textViewName = findViewById(R.id.name);
        imageViewProfile = findViewById(R.id.profile_img);
        saveButton = findViewById(R.id.saveButton);

        dbHelper = new ImageDatabaseHelper(this);

        imageViewProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open image selection activity
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, 1);
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imagePath != null && !imagePath.isEmpty()) {
                    saveUserInfo();
                    // Navigate to home page or any other destination
                    startActivity(new Intent(ProfileActivity.this, MainActivity.class));
                    finish();
                } else {
                    Toast.makeText(ProfileActivity.this, "Please select an image", Toast.LENGTH_SHORT).show();
                }
            }
        });

        loadUserInfo();
    }

    private void loadUserInfo() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserInfo", MODE_PRIVATE);
        String name = sharedPreferences.getString("Name", "");
        textViewName.setText(name);

        String imagePath = dbHelper.getImagePath();
        if (!imagePath.isEmpty()) {
            File imgFile = new File(imagePath);
            if (imgFile.exists()) {
                Bitmap bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                imageViewProfile.setImageBitmap(bitmap);
                // Enable the save button since an image is already selected
                saveButton.setEnabled(true);
            } else {
                // If the image file doesn't exist, you can set a default image
                imageViewProfile.setImageResource(R.drawable.baseline_person_24);
            }
        } else {
            // If no image path is stored, set a default image
            imageViewProfile.setImageResource(R.drawable.baseline_person_24);
        }
    }

    private void saveUserInfo() {
        // Save user name to SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("UserInfo", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("Name", textViewName.getText().toString());
        editor.apply();

        // Save the image path to SQLite database
        dbHelper.saveUserInfo(textViewName.getText().toString(), imagePath);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 1 && data != null) {
            // Get the selected image path from the data Intent
            imagePath = data.getData().toString();
            if (imagePath != null && !imagePath.isEmpty()) {
                // Load and display the selected image
                imageViewProfile.setImageURI(data.getData());
                // Enable the save button since an image is selected
                saveButton.setEnabled(true);
            }
        }
    }
}
